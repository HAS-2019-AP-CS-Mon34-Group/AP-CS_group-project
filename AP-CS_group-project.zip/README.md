# AP-CS_group-project
Java Based Text analysis: KakaoTalk Chat